package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class GooglePage extends BasePage{

    public GooglePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(name = "q")
    private WebElement searchBox;

    @FindBy(name="btnK")
    private WebElement searchButton;

    @FindBy(xpath = "//div[@id='rso']/div[contains(@class,'g') and not(@data-ved)]/div[@class='rc']/div[1]/a")
    private List<WebElement> results;

    @FindBy(id="result-stats")
    private WebElement resultStats;

    @FindBy(xpath = "//a[descendant::text()='Images']")
    private WebElement imageLink;


    @FindBy(xpath= "//a[descendant::text()='Videos']")
    private WebElement videoLink;

    @FindBy(xpath ="//a[descendant::text()='News']")
    private WebElement newLink;

    @FindBy(css = "#islmp #islrg .islrc div")
    private List<WebElement> imageResultStats;

    public void goTo(){
        this.driver.get("https://www.google.com");
    }

    public void inputKeyword(String keyword){
        this.searchBox.clear();
        this.searchBox.sendKeys(keyword);
    }

    public void clickOnSearchButton(){
        this.searchBox.sendKeys(Keys.ENTER);
    }

    public void clickOnResultWithIndex(int i){
        this.wait.until((d) -> this.results.size() > 0);
        this.results.get(i).click();
    }

    public void goBack(){
        this.driver.navigate().back();
        this.wait.until((d) -> this.searchBox.isDisplayed());
    }

    public void clickOnImageLink(){
        this.imageLink.click();
    }

    public void clickOnVideoLink(){
        this.videoLink.click();
    }

    public void clickOnNewLink(){
        this.newLink.click();
    }

    public void printResultStats(){
        System.out.println(this.resultStats.getText());
    }

    public void printImageResults(){
        System.out.println(this.imageResultStats.size());
    }

    @Override
    public boolean isAt() {
        return wait.until((d) -> this.searchBox.isDisplayed());
    }
}
