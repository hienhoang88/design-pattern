package test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.GooglePage;

public class GoogleTest extends BaseTest{

    private GooglePage googlePage;

    @BeforeTest
    public void pageSetup(){
        this.googlePage = new GooglePage(driver);
    }

    @Test
    public void searchTest(){
        this.googlePage.goTo();
        this.googlePage.inputKeyword("spring boot");
        this.googlePage.clickOnSearchButton();
        this.googlePage.clickOnResultWithIndex(1);
        this.googlePage.goBack();
        this.googlePage.inputKeyword("spring boot");
        this.googlePage.clickOnSearchButton();

        this.googlePage.clickOnImageLink();
        this.googlePage.printImageResults();
        this.googlePage.clickOnVideoLink();
        this.googlePage.printResultStats();
        this.googlePage.clickOnNewLink();
        this.googlePage.printResultStats();

    }
}
